# The Containers Package

This package contains additional functionality that supports building containerized REST web services with functions from other packages.